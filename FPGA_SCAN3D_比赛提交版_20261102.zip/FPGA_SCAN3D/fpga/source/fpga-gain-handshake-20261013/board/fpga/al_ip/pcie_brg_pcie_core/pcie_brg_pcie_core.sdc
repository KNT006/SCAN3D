set_hxt_property RX0_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property RX0_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX0_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX0_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]

set_hxt_property RX1_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property RX1_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX1_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX1_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]

set_hxt_property RX2_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property RX2_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX2_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX2_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]

set_hxt_property RX3_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property RX3_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX3_OUTCLK  2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]
set_hxt_property TX3_OUT2CLK 2 [get_cells {u2_pcie_brg_pcie_core_phy0_top}]

